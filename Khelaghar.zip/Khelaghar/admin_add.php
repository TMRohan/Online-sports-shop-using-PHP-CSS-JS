<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $title; ?></title>

    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
   
  </head>
<?php
	session_start();
	require_once "./functions/admin_home.php";
	$title = "Add new product";
	require "./template/header.php";
	require "./functions/database_functions.php";
	$conn = db_connect();

	if(isset($_POST['add'])){
		$productId = trim($_POST['productId']);
		$productId = mysqli_real_escape_string($conn, $productId);
		
		$name = trim($_POST['Name']);
		$name = mysqli_real_escape_string($conn, $Name);

		$type = floatval(trim($_POST['type']));
		$type = mysqli_real_escape_string($conn, $type);
		
		$description = trim($_POST['description']);
		$description = mysqli_real_escape_string($conn, $description);
		
		$price = floatval(trim($_POST['price']));
		$price = mysqli_real_escape_string($conn, $price);
		
		$available = floatval(trim($_POST['available']));
		$available = mysqli_real_escape_string($conn, $available);
		
		

		// add image
		if(isset($_FILES['image']) && $_FILES['image']['name'] != ""){
			$image = $_FILES['image']['name'];
			$directory_self = str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']);
			$uploadDirectory = $_SERVER['DOCUMENT_ROOT'] . $directory_self . "bootstrap/img/";
			$uploadDirectory .= $image;
			move_uploaded_file($_FILES['image']['tmp_name'], $uploadDirectory);
		}

		// find publisher and return pubid
		// if publisher is not in db, create new
		

		$query = "INSERT INTO product VALUES ('" . $productId . "', '" . $name . "','" . $type . "', '" . $image . "', '" . $description . "', '" . $price . "','" . $available . "')";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't add new data " . mysqli_error($conn);
			exit;
		} else {
			header("Location: admin_book.php");
		}
	}
?>
	<form method="post" action="admin_add.php" enctype="multipart/form-data">
		<table class="table">
			<tr>
				<th>ProductId</th>
				<td><input type="text" name="productId"></td>
			</tr>
			<tr>
				<th>Name</th>
				<td><input type="text" name="name" required></td>
			</tr>
			<tr>
				<th>Product Type</th>
				<td><input type="text" name="type" required></td>
			</tr>
			
			<tr>
				<th>Image</th>
				<td><input type="file" name="image"></td>
			</tr>
			<tr>
				<th>Description</th>
				<td><textarea name="description" cols="40" rows="5"></textarea></td>
			</tr>
			<tr>
				<th>Price</th>
				<td><input type="text" name="price" required></td>
			</tr>
			<tr>
				<th>Available</th>
				<td><input type="text" name="available" required></td>
			</tr>
			
		</table>
		<input type="submit" name="add" value="Add new product" class="btn btn-primary">
		<input type="reset" value="cancel" class="btn btn-default">
	</form>
	<br/>
<?php
	if(isset($conn)) {mysqli_close($conn);}
	require_once "./template/footer.php";
?>