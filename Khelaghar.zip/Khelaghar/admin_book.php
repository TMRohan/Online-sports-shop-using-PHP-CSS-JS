<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $title; ?></title>

    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
   
  </head>
<?php
	session_start();
	require_once "./functions/admin_home.php";
	$title = "List product";
	require_once "./template/header.php";
	require_once "./functions/database_functions.php";
	$conn = db_connect();
	$result = getAll($conn);
?>
	<p class="lead"><a href="admin_add.php">Add new product</a></p>
	<a href="admin_signout.php" class="btn btn-primary">Sign out!</a>
	<table class="table" style="margin-top: 20px">
		<tr>
			<th>ProductId</th>
			<th>Name</th>
			<th>type</th>
		
			<th>Image</th>
			<th>Description</th>
			<th>Price</th>
			<th>Available</th>
			
			
			<th>&nbsp;</th>
			<th>&nbsp;</th>
		</tr>
		<?php while($row = mysqli_fetch_assoc($result)){ ?>
		<tr>
			<td><?php echo $row['productId']; ?></td>
			<td><?php echo $row['Name']; ?></td>
			<td><?php echo $row['type']; ?></td>

			<td><?php echo $row['image']; ?></td>
			<td><?php echo $row['description']; ?></td>
			<td><?php echo $row['price']; ?></td>
			<td><?php echo $row['available']; ?></td>
			
			<td><a href="admin_edit.php?productId=<?php echo $row['productId']; ?>">Edit</a></td>
			<td><a href="admin_delete.php?productId=<?php echo $row['productId']; ?>">Delete</a></td>
		</tr>
		<?php } ?>
	</table>

<?php
	if(isset($conn)) {mysqli_close($conn);}
	require_once "./template/footer.php";
?>