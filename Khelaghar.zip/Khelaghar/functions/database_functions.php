<?php
	function db_connect(){
		$conn = mysqli_connect("localhost", "root", "", "khelaghar");
		if(!$conn){
			echo "Can't connect database " . mysqli_connect_error($conn);
			exit;
		}
		return $conn;
	}

	function select4Latestproduct($conn){
		$row = array();
		$query = "SELECT productId,image,price FROM product ORDER BY productId DESC";
		$result = mysqli_query($conn, $query);
		if(!$result){
		    echo "Can't retrieve data " . mysqli_error($conn);
		    exit;
		}
		for($i = 0; $i < 4; $i++){
			array_push($row, mysqli_fetch_assoc($result));
		}
		return $row;
	}

	function getproductid($conn, $id){
		$query = "SELECT Name,price FROM product WHERE productId = '$id'";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;
	}

	function getOrderId($conn, $customerid){
		$query = "SELECT orderid FROM orders WHERE customerId = '$customerId'";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "retrieve data failed!" . mysqli_error($conn);
			exit;
		}
		$row = mysqli_fetch_assoc($result);
		return $row['orderid'];
	}

	function insertIntoOrder($conn, $customerId, $total_price,$ship_name, $ship_address, $ship_city, $phonenumber){
		$query = "INSERT INTO orders VALUES 
		('', '" . $customerId . "', '" . $total_price . "','" . $ship_name . "', '" . $ship_address . "', '" . $ship_city . "', '" . $phonenumber . "')";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Insert orders failed " . mysqli_error($conn);
			exit;
		}
	}

	function getproductprice($id){
		$conn = db_connect();
		$query = "SELECT price FROM product WHERE productId = '$id'";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "get product price failed! " . mysqli_error($conn);
			exit;
		}
		$row = mysqli_fetch_assoc($result);
		return $row['price'];
	}

	function getCustomerId($Name, $Address, $City, $phonenumber){
		$conn = db_connect();
		$query = "SELECT customerId from customer WHERE 
		Name = '$Name' AND 
		Address= '$Address' AND 
		City = '$City' AND 
		phonenumber = '$phonenumber'" ;
		
		$result = mysqli_query($conn, $query);
		// if there is customer in db, take it out
		if($result){
			$row = mysqli_fetch_assoc($result);
			return $row['customerId'];
		} else {
			return null;
		}
	}

	function setCustomerId($Name, $Address, $City, $phonenumber){
		$conn = db_connect();
		$query = "INSERT INTO customer VALUES 
			('', '" . $Name . "', '" . $Address . "', '" . $City . "', '" . $phonenumber . "')";

		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "insert false !" . mysqli_error($conn);
			exit;
		}
		$customerId = mysqli_insert_id($conn);
		return $customerId;
	}
	
    function signin_Query($email,$pass)
    {
        return mysqli_query(connection(),"SELECT * FROM users WHERE email='$email' AND password='$pass'");
    }

    function signup_Query($name,$uname,$email,$password,$gender,$mobile,$image)
    {
        $status=1;
        $type="user";
      $query="INSERT INTO users(name,username,email,password,gender,mobile,image,user_type,status) VALUES('$name','$uname','$email','$password','$gender','$mobile','$image','$type','$status')";  
      
     mysqli_query(connection(),$query);
    }


function email_Query($email)
{
	return mysqli_query(connection(),"SELECT * FROM users WHERE email='$email'");
}


function update_Query($name,$uname,$email,$password,$mobile,$image)
{
	
	$sql="UPDATE users SET name='$name', username='$uname', email='$email', password='$password',mobile='$mobile',image='$image' WHERE email='$email'";
	mysqli_query(connection(),$sql);
}


function user_all_data($email)

{
    
    return mysqli_query(connection(),"SELECT * FROM users WHERE email='$email'");
    
}  
    



function getAll($conn){
		$query = "SELECT * from product ORDER BY productId DESC";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;
	}
	function getAll1($conn){
		$query = "SELECT * from order_items ORDER BY productId DESC";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;
	}
	function getAll2($conn){
		$query = "SELECT * from customer ORDER BY customerId DESC";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;
	}

?>



	
