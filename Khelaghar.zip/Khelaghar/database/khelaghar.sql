-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2019 at 09:16 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `khelaghar`
--

-- --------------------------------------------------------

--
-- Table structure for table `cricket`
--

CREATE TABLE `cricket` (
  `productId` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `price` int(100) NOT NULL,
  `available` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cricket`
--

INSERT INTO `cricket` (`productId`, `Name`, `image`, `description`, `price`, `available`) VALUES
('233', 'New balance cricket bat', 'bat3.jpg', 'New Balance DC 1080 English Willow Cricket Bat, a top of the line DC Series cricket bat is now available on crickstore', 1400, 20),
('240', 'Kookabura Test cricket ball', 'ball.jpg', 'The best balls in the business from the worlds number one cricket ball manufacturer. MODEL: PACEBALL CODE: The Kookaburra Paceball Cricket Ball is a hand stitched 4-piece construction cricket ball with 3 layer centre and Grad 2 alum tanned steer hide cover. Colours: Red & White Sizes: 156g & 142g', 800, 15);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerId` varchar(11) NOT NULL,
  `Name` varchar(11) NOT NULL,
  `Address` varchar(111) NOT NULL,
  `City` varchar(111) NOT NULL,
  `phonenumber` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerId`, `Name`, `Address`, `City`, `phonenumber`) VALUES
('1', 'Rohan', 'nikunja', 'dhaka', 1619971120),
('2', 'ronaldo', 'nikunja', 'dhaka', 1619271120),
('3', 'Neymar', 'kuril', 'dhaka', 1319971120),
('', '', 'kuay', 'Wes', 123456);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` varchar(100) NOT NULL,
  `customerId` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `ship_name` varchar(100) NOT NULL,
  `ship_address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `customerId`, `amount`, `ship_name`, `ship_address`, `city`, `phonenumber`) VALUES
('', '0', '2400', '', '', '', ''),
('', '0', '2400', '', '', '', ''),
('', '0', '2400', '', '', '', ''),
('', '0', '2400', '', '', '', ''),
('', '0', '2400', '', '', '', ''),
('', '0', '2400', '', '', '', ''),
('', '0', '1800', '', 'North, 60 Milton Way', 'West Drayton', '123456'),
('', '0', '222', '', ' Way', 'West ', '123456'),
('', '0', '2700', '', '', '', ''),
('', '0', '1800', '', 'comilla', 'dhaka', '1234'),
('', '0', '4600', '', 'North, 60 Milton Way', 'West Drayton', '123456'),
('', '0', '2400', '', 'kuay', 'Wes', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `orderid` varchar(100) NOT NULL,
  `productId` varchar(100) NOT NULL,
  `item_price` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`orderid`, `productId`, `item_price`, `quantity`) VALUES
('', '223', '900', '1'),
('', '2', '111', '1'),
('', '223', '900', '2'),
('', '223', '900', '1'),
('', '69', '2300', '1'),
('', '25', '1200', '1');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productId` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `price` int(100) NOT NULL,
  `available` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productId`, `Name`, `type`, `image`, `description`, `price`, `available`) VALUES
(1, 'Real_Madrid away jersey2019', 'jersey', 'real.jpg', 'Get ready for the new season with Real Madrid. The dark grey shirt has light grey accents on the collar, cuffs and shoulder stripes. Embroidered adidas logo and rubber heat press Real Madrid crest on the chest. Steam-pressed Fly Emirates on front. Regular fit. ClimaCool technology pulls moisture from the skin. 100% polyester.', 600, 10),
(2, 'Bangladesh Criket Team Jersey', 'jersey', 'bd.jpeg', 'Product Type: Jersey\r\nGood Quality Product\r\nStylish and Comfortable', 111, 10),
(25, 'cr7 cap', 'cap', 'cr7cap.jpg', 'New 2017 Cristiano Ronaldo CR7 Gold Letter Black Baseball Caps hip hop Sports Snapback cap hat chapeu de sol bone Men', 1200, 25),
(69, 'adidas erdiga ruuning shoes', 'shoes', 'shoes1.jpg', 'Regular fit,Ergonomic cut lines for maximum freedom of movement and comfort\r\nReversed coverlock stitching for higher comfort\r\nBack neck tape for reduced chaffing\r\nDropped back hem for enhanced coverage during exercise', 2300, 20),
(123, 'australia t20', '', 'australia.jpg', 'Regular fit\r\nErgonomic cut lines for maximum freedom of movement and comfort\r\nReversed coverlock stitching for higher comfort\r\nBack neck tape for reduced chaffing\r\nDropped back hem for enhanced coverage during exercise', 600, 2),
(223, 'Adidas PREDATOR GROUND BOOTS', 'shoes', 'adidas.jpg', 'PREDATOR 19.2 FIRM GROUND BOOTS PRECISION BOOTS RESERVED FOR PLAYERS WHO DARE TO DOMINATE. If your command of the pitch leaves your rivals\' tactics in tatters, you\'re ready to own Predators. Built for precision on firm ground, these football boots have a supportive mesh upper with a snug-fitting collar that locks you in for total control. On the forefoot a grippy, textured coating adds confidence to every touch.', 900, 20);

-- --------------------------------------------------------

--
-- Table structure for table `sportswear`
--

CREATE TABLE `sportswear` (
  `jersey` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sportswear`
--

INSERT INTO `sportswear` (`jersey`) VALUES
('Under Armour Forge V Neck T Shirt Mens'),
('Nike JDI Shadow T Shirt Mens'),
('Brazil Team jersey Mens'),
('Manchaster United Jersey Men');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `phoneno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `user_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `password`, `address`, `phoneno`, `email`, `image`, `user_type`) VALUES
('admin', 'admin', '', '', '', '', ''),
('abul', 'abcd123', 'cp', '01234567', 'abul@gmail.com', 'image.jpg', ''),
('rohan', 'abcd', 'nikunja', '01619971120', 'rohan1@gmail.com', '', ''),
('ronaldo', 'abcd123@', 'cp', '01619971120', 'ron@mail.com', 'images.jpg', 'user'),
('rohan', '123456789@', 'cp', '01619971120', 'tanvir@gmail.com', 'image.jpg', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
