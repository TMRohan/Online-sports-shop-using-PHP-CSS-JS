<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $title; ?></title>

    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
   
  </head>
<?php
	session_start();
	require_once "./functions/admin_home.php";
	$title = "Edit product";
	require_once "./template/header.php";
	require_once "./functions/database_functions.php";
	$conn = db_connect();

	if(isset($_GET['productId'])){
		$productId = $_GET['productId'];
	} else {
		echo "Empty query!";
		exit;
	}

	if(!isset($productId)){
		echo "Empty id! check again!";
		exit;
	}

	// get book data
	$query = "SELECT * FROM product WHERE productId = '$productId'";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Can't retrieve data " . mysqli_error($conn);
		exit;
	}
	$row = mysqli_fetch_assoc($result);
?>
	<form method="post" action="edit_product.php" enctype="multipart/form-data">
		<table class="table">
			<tr>
				<th>Product Id</th>
				<td><input type="text" name="isbn" value="<?php echo $row['productId'];?>" readOnly="true"></td>
			</tr>
			<tr>
				<th>Name</th>
				<td><input type="text" name="title" value="<?php echo $row['Name'];?>" required></td>
			</tr>
			<tr>
				<th>Type</th>
				<td><input type="text" name="type" value="<?php echo $row['type'];?>" required></td>
			</tr>
			<tr>
				<th>Image</th>
				<td><input type="file" name="image"></td>
			</tr>
			<tr>
				<th>Description</th>
				<td><textarea name="descr" cols="40" rows="5"><?php echo $row['description'];?></textarea>
			</tr>
			<tr>
				<th>Price</th>
				<td><input type="text" name="price" value="<?php echo $row['price'];?>" required></td>
			</tr>
			<tr>
				<th>Available</th>
				<td><input type="text" name="available" value="<?php echo $row['available'];?>" required></td>
			</tr>
		</table>
		<input type="submit" name="save_change" value="Change" class="btn btn-primary">
		<input type="reset" value="cancel" class="btn btn-default">
	</form>
	<br/>
	<a href="admin_book.php" class="btn btn-success">Confirm</a>
<?php
	if(isset($conn)) {mysqli_close($conn);}
	require "./template/footer.php"
?>