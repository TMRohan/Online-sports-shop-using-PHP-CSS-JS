<?php
?>
<html>
	<head>
		<title>Footer</title>
		<script>
function validateForm() {
  var x = document.forms["myForm"]["fname"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }


  var y = document.forms["myForm"]["email"].value;
  if (y == "") {
    alert("email must be filled out");
    return false;
  }


  var z = document.forms["myForm"]["comment"].value;
  if (z == "") {
    alert("Comment must be filled out");
    return false;
  }
}
</script>
	</head>
	
	<body height="768" width="1366">
		<font face="arial">
			<table align="left" bgcolor="#0E6655" height="180" width="1400">
				<tr>
					<td width="450" align="center">
						<p align="left"><b><font color="Black" size="5">About</font></b></p>
						<p align="left"><a href=""><b><font color="white" size="3"><a href="about.php">About KhelaGhor</font></b></a><p>
						<p align="left"><a href=""><b><font color="white" size="3"><a href="contact.php">Contact Us</font></b></a></p>
					</td>	
					<td width="450" align="center">
						
						<p align="left"><b><font color="Black" size="5">Legal</font></b></p>
						<p align="left"><a href=""><b><font color="white" size="3"><a href="privacy.php">Privacy Policy</font></b></a></p>
						<p align="left"><a href=""><b><font color="white" size="3"><a href="terms.php">Terms & Conditions</font></b></a></p>
						
						
					</td>
					<td>
							<h4>Feedback</h4>
							<form name="myForm" action=" " onsubmit="return validateForm()" method="post">
                              Name: <input type="text" name="fname"><br>
                              <form name="myForm" action=" " onsubmit="return validateForm()" method="post">
                              Email: <input type="text" name="email"><br/>
							  <form name="myForm" action=" " onsubmit="return validateForm()" method="post">
                              Comment: <input type="text" name="comment"><br/>
                               

							
								
								<input type="submit" value="Submit">
							</form>
						
					<td>
					<td width="450" align="center">
						<p align="center"><b><font color="Black" size="5">Follow Us</font></b></p>
						<p align="center">
							<a href="http://www.facebook.com"><img src="bootstrap/img/facebook.png"></a> 
							<a href="http://www.twitter.com"><img src="bootstrap/img/twitter.png"></a> 
							
						</p>	
					</td>
				</tr>	
			</table>
		</font>
	</body>
<html>