<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $title; ?></title>

    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
   
  </head>
 <html>
	<head>
		<title>Welcome to Khelaghor</title>
		<style>
			*{
				padding:0;
				margin:0;
				box-sizing:border-box;
			}

			.wrapper{
				
				position:relative;
			}

			
			h2{
				padding:50px;
				background:#112233;
				color:#f0f1f5;
				font-family: big john;
				text-align: center;
				font-size:30pt;
				letter-spacing: 15px;
			}

			.navigationDesktop{
				background:#fc575e;
			}

			nav {
				height:40px;
				width:100%; 
				display:block;
				text-align: center;
				text-transform: uppercase;
			}

			nav a{
				display:block;
				text-decoration: none;
				font-family: monospace;
				font-weight: bold;
				font-size:13pt;
				color:#112233;
			}

			nav a:hover{
				background:#223433;
				color:#f0f1f5;
			}

			nav ul{
				list-style: none;
			}

			nav ul li{
				float:left;
				width:140px;
				height:40px;
				line-height: 40px;
				background:#fc575e;
			}
			
			nav ul .aa{
				float:right;
				
			}
			
			nav ul .aa2{
				float:right;
				
			}
			nav ul ul li{
				position:relative;
				display:none;
			}

			nav ul ul ul{
				display:none;
			}

			nav ul li:hover ul li{
				display: block;
				animation: navmenu 500ms forwards;
			}

			@keyframes navmenu{
				0%{
					opacity:0;
					top:5px;
				}
				100%{
					opacity:1;
					top:0px;
				}
			}

			nav ul ul li:hover ul{
				display:block;
				position:absolute;
				width:140px;
				left:140px;
				top:0px;
			}

			

			
		</style>
	</head>
	<body>
		<div class="wrapper">
			<header>
				<h2>Khelaghor</h2>
			</header>
			<div class="navigationDesktop">
				<nav>
					<ul>
					    <li><a href="index.php">Home</a></li>
						<li><a href="#">Sportswear</a>
							<ul>
								<li><a href="jersey.php">Jersey</a></li>
								<li><a href="caps.php">Cap</a></li>
								<li><a href="shoes.php">Shoes</a></li>
							</ul>
						</li>
						<li><a href="cricket.php">Cricket</a>
							<ul>
								<li><a href="#">Bat</a></li>
								<li><a href="#">Ball</a></li>
							</ul>
						</li>
						<li><a href="discount.php">Discount</a>
							
						</li>
						<li class="aa2"><a href="myhome.php">My Profile</a></li>
						<li class="aa"><a href="cart.php">My cart</a></li>
						
					</ul>
				</nav>
			</div>
		</div>
	</body>
</html>