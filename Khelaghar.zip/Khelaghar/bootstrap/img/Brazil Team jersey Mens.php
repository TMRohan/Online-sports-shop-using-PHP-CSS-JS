<html>
     <head>
	      <title>Brazil Team jersey Mens </title>
	</head>
		<body bgcolor="#000000">	
			<table bgcolor="#000000">
			   <tr>
		          <th height="30"width="800"align="left"><a href="index.php"><font COLOR="white" size="7">KhelaGhor</font></a></th>
		          
			   </tr>
			</table>
			<table>
				<tr>
		  
	
			        <td valign="bottom"  width="80"><a href=""><button><b><font color="black" size="4">Home</font></b></button></a></td>
					<td valign="bottom"  width="80"><a href="sportwear.php"><button><b><font color="black" size="4">SportsWear</font></b></button></a></td>
					<td valign="bottom" align="center" width="80"><a href="cricket.php"><button><b><font color="black" size="4">Cricket</font></b></button></a></td>
					<td valign="bottom" align="right" width="80"><a href="football.php"><button><b><font color="black" size="4">Football</font></b></button></a></td>
					<td valign="bottom" align="right" width="80"><a href="tshirt.php"><button><b><font color="black" size="4">T-shirt</font></b></button></a></td>
					<td align="right"width="420"><input type="text" placeholder="product name.." name="search"size="36"/></td>
					<td width="20"><button><b><font color="black" size="4">Search</font></b></button></td>	
					
					
					
				</tr>
			<table>
			<tr>
			    <td valign="top" height="600"width="600"><img src="brazil.jpg"width="600"height="600">
			<td height="400"width="1000"valign="top"><font size="6"color="WHITE"><u>Brazil Team jersey Mens </u><br/>
			<p><font size="6"color="RED"><u>Price:399.00 TAKA</u></font></p>
			
			<p><font size="6"color="RED"><u>Product Description:</u></font><br/>
			<li>Regular fit</li>
<li>Ergonomic cut lines for maximum freedom of movement and comfort</li>
<li>Reversed coverlock stitching for higher comfort</li>
<li>Back neck tape for reduced chaffing</li>
<li>Dropped back hem for enhanced coverage during exercise</li>

</p>
<p><font size="6"color="RED"><u>Size:</u></font><br/>
			       <input type="radio" name="size" value="XXL"/>XXL<br/>
			       <input type="radio" name="size" value="XL"/>XL<br/>
				   <input type="radio" name="size" value="L"/>L<br/>
			       <input type="radio" name="size" value="M"/>M<br/>
				   
				<input type="submit"/>
			<p><font size="6"color="RED"><u>Quantity:</u></font>
			       <input type="text"name="Quantity">
				   <input type="submit"name="submit">
			
			<p><a href="mycart.php"><button><b><font color="black" size="4">Add to cart</font></b></button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="wishlist.php"><button><b><font color="black" size="4">Add to wishlist</font></b></button></a>
			
			
			</td>
			</tr>
			<td>
			<p><font size="6"color="RED"><u>Rating:</u><br/>
			       <input type="radio" name="size" value="1"/>1<br/>
			       <input type="radio" name="size" value="2"/>2<br/>
				   <input type="radio" name="size" value="3"/>3<br/>
			       <input type="radio" name="size" value="4"/>4<br/>
				   <input type="radio" name="size" value="5"/>5<br/>
				   
				<input type="submit"/>
			
			
			
			
			
			
			</table>
			<?php
		   include 'footer.php';
	    ?>
	</body>
</html>	