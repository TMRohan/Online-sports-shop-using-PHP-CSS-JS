<?php



?>

<html>
	<head>
		<title>Sign In</title>
	</head>
	<body bgcolor="#000000" height="768" width="1366">
		<font face="arial">
		   <form action="signin_handler.php" method="POST">
				<table bgcolor="black" align="center" height="600" width="650">
					<tr height="270" width="301">
						<td align="center"><font size="12"color="white"><i>KhelaGhor</td>
						<td valign="top" height="30" width="30"><a href="home.php"></a></td>
					</tr>
					<tr>
						<td align="center" height="70" colspan="2"><b><font color="#E74C3C" size="6">Sign In</font></b>
						<br/>
						<font color="white" size="3"><label><?php echo $_GET['msgerr']?></label></font> 
					 </td>

					</tr>
						
					<tr>
						<td valign="bottom" align="center" height="15" colspan="2">
							<font color="white" size="4">Email:</font>&nbsp
							<input type="text" name="email" 
                            value="<?php if(isset($_COOKIE["email"]))  {echo $_COOKIE["email"];}?>" 
                                   placeholder="Please enter your email" size="40"/>
							<br/>
							<font color="white" size="3"><label><?php echo $_GET['msge']?></label></font>
						</td>
					</tr>
					
					<tr>
						<td valign="top" align="center" height="15" colspan="2">
							<font color="white" size="4">Password:</font>&nbsp
							<input type="password" name="password"   
                                   value="<?php if(isset($_COOKIE["pass"]))  {echo $_COOKIE["pass"];}?>"
                                   placeholder="Enter your password"size="40"/>
							<br/>
							<font color="white" size="3"><label><?php echo $_GET['msgp']?></label></font>						
						</td>
					</tr>
                    <tr>
                    <td valign="top" align="center" height="15" colspan="2">
                        <input type="checkbox" name="remember" <?php if(isset($_COOKIE["email"])) {?> <?php }?> /><font color="white" size="3">remember me</font>
                    
                    </tr>
					
					<tr>
						<td align="center" height="60" colspan="2"><button type="submit" name="login"><b><font color="black" size="4">Login</font></b></button></td>
					</tr>
						
					<tr>
						<td align="left" height="60" colspan="2"><b><font color="white" size="4">Don't have an account?<a href="registration.php"><b> Register</b></a>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
						<b><font size="4"><b><a href="forgotpass.php" color=>Forgot Password?</b></a>
						</td>
					</tr>
						</td>
					</tr>
				</table>
			</form>
		</font>
	</body>
</html>