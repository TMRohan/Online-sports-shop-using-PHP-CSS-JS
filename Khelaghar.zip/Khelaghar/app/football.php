<html>
     <head>
	      <title>Football</title>
	</head>
		<body bgcolor="#000000">	
			<table bgcolor="#000000">
			   <tr>
		          <th height="30"width="800"align="left"><a href="index.php"><font COLOR="white" size="7">KhelaGhor</font></a></th>
		          
			   </tr>
			</table>
			<table>
			<tr bgcolor="#1C2833">	
			  <th align="center"colspan="3"><font size="6"color="WHITE">Football</th>
			</tr>
			<tr bgcolor="#1C2833">	
			  <th align="center"colspan="3"><font size="6"color="WHITE">Ball</th>
			</tr>
			<tr>
			    <td width="455"height="300"><img src="fball1.jpg"width="455"height="300">
				<td width="455"height="300"><img src="nike.jpg"width="455"height="300">
				<td width="455"height="300"><img src="ucl.jpg"width="455"height="300">
			</tr>
			<tr>
			    <td align="center" width="455"height="30"><b><font color="white"size="3">Telstar Football</font></td>
				<td align="center" width="455"height="30"><b><font color="white"size="3">Nike laliga ball<height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">Adidas ucl ball<width="455"height="300">
			</tr>
			<tr>
			    <td align="center"width="455"height="30"><b><font color="white"size="3">Price:1399.00 TAKA<width="455"height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">PRICE:999.00 TAKA<height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">PRICE:1110.00 TAKA<width="455"height="300">
			</tr>
			<tr bgcolor="#1C2833">	
			        <td valign="bottom"align="center" width="455"height="20"><a href="Telstar Football.php"><button><b><font color="blue" size="4">View Details</font></b></button></a></td>
					<td valign="bottom" align="center" width="455"height="20"><a href="Nike laliga ball.php"><button><b><font color="blue" size="4">View Details</font></b></button></a></td>
					<td valign="bottom" align="center" width="455"height="20"><a href="Adidas ucl ball.php"><button><b><font color="blue" size="4">view Details</font></b></button></a></td>
			</tr>
			<tr bgcolor="#1C2833">	
			  <th align="center"colspan="3"><font size="6"color="WHITE">Boot</th>
			</tr>
			<tr>
			    <td width="455"height="300"><img src="puma.jpg"width="455"height="300">
				<td width="455"height="300"><img src="nikeboot.jpg"width="455"height="300">
				<td width="455"height="300"><img src="adidasboot.jpg"width="455"height="300">
			</tr>
			<tr>
			    <td align="center" width="455"height="30"><b><font color="white"size="3">Puma Evopwer boot</font></td>
				<td align="center" width="455"height="30"><b><font color="white"size="3">Nike vapor12 elite<height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">Adidas copa boot<width="455"height="300">
			</tr>
			<tr>
			    <td align="center"width="455"height="30"><b><font color="white"size="3">Price:2100.00 TAKA<width="455"height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">PRICE:1699.00 TAKA<height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">PRICE:1790.00 TAKA<width="455"height="300">
			</tr>
			<tr bgcolor="#1C2833">	
			        <td valign="bottom"align="center" width="455"height="20"><a href="Puma Evopwer boot.php"><button><b><font color="blue" size="4">View Details</font></b></button></a></td>
					<td valign="bottom" align="center" width="455"height="20"><a href="Nike vapor12 elite.php"><button><b><font color="blue" size="4">View Details</font></b></button></a></td>
					<td valign="bottom" align="center" width="455"height="20"><a href="Adidas copa boot.php"><button><b><font color="blue" size="4">view Details</font></b></button></a></td>
			</tr>
			
			
			
			
			
			
			
			</table>
			</table>
			<?php
		   include 'footer.php';
	    ?>
	</body>
</html>	