<html>
     <head>
	      <title>Jersey</title>
	</head>
		<body bgcolor="#000000">	
			<table bgcolor="#000000">
			   <tr>
		          <th height="30"width="800"align="left"><a href="index.php"><font COLOR="white" size="7">KhelaGhor</font></a></th>
		         
			   </tr>
			</table>
			<table border="1">
			<tr bgcolor="#1C2833">	
			  <th align="left"colspan="2"><font size="6"color="WHITE">Jersey</th>
			  <td align="center"><font color="white"size="5">
						<select name="Size">
						<option value="null">Choose by Size</option>
						<option value="XXL">XXL</option>
						<option value="XL">XL</option>
						<option value="L">L</option>
						<option value="M">M</option>
						</select>
						<td>
			</tr>
			<tr>
			    <td width="455"height="300"><img src="brazil.jpg"width="455"height="300">
				<td width="455"height="300"><img src="manu.jpg"width="455"height="300">
				<td width="455"height="300"><img src="australia.jpg"width="455"height="300">
			</tr>
			<tr>
			    <td align="center" width="455"height="30"><b><font color="white"size="3">Brazil Team jersey Mens</font></td>
				<td align="center" width="455"height="30"><b><font color="white"size="3">Manchaster United Jersey Mens<height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">Australia T20 Jersey<width="455"height="300">
			</tr>
			<tr>
			    <td align="center"width="455"height="30"><b><font color="white"size="3">Price:399.00 TAKA<width="455"height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">PRICE:599.00 TAKA<height="300">
				<td align="center"width="455"height="30"><b><font color="white"size="3">PRICE:780.00 TAKA<width="455"height="300">
			</tr>
			<tr bgcolor="#1C2833">	
			        <td valign="bottom"align="center" width="455"height="20"><a href="Brazil Team jersey Mens.php"><button><b><font color="blue" size="4">View Details</font></b></button></a></td>
					<td valign="bottom" align="center" width="455"height="20"><a href="Manchaster United Jersey Mens.php"><button><b><font color="blue" size="4">View Details</font></b></button></a></td>
					<td valign="bottom" align="center" width="455"height="20"><a href="Australia T20 Jersey.php"><button><b><font color="blue" size="4">view Details</font></b></button></a></td>
			</tr>
			
			
			
			
			
			</table>
			</table>
			<?php
		   include 'footer.php';
	    ?>
	</body>
</html>	