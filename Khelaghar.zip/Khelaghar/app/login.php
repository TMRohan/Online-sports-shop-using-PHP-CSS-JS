<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $title; ?></title>

    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
   
  </head>
<?php
	$title ="";
	include_once "./template/header.php";
?>

	<form class="form-horizontal" method="post" action="user_verify.php">
		<div class="form-group">
			<label for="email" class="control-label col-md-4">Email</label>
			<div class="col-md-4">
				<input type="text" name="email" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<label for="pass" class="control-label col-md-4">Password</label>
			<div class="col-md-4">
				<input type="password" name="password" class="form-control">
			</div>
		</div>
		
		<input type="submit" name="submit" class="btn btn-primary">
		<tr>
						<td align="left" height="60" colspan="2"><b><font color="white" size="4">Don't have an account?<a href="registration.php"><b> Register</b></a>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
						<b><font size="4"><b><a href="forgetpass.php" color=>Forgot Password?</b></a>
						</td>
					</tr>
	</form>

<?php
	require_once "./template/footer.php";
?>