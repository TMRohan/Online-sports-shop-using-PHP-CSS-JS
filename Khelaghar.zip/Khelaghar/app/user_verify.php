<?php
	session_start();
	if(!isset($_POST['submit'])){
		echo "Something wrong! Check again!";
		exit;
	}
	include_once "./functions/database_functions.php";
	$conn = db_connect();

	$email = trim($_POST['email']);
	$password = trim($_POST['password']);

	if($email == "" || $password == ""){
		echo "email or Pass is empty!";
		exit;
	}

	$email = mysqli_real_escape_string($conn, $email);
	$password = mysqli_real_escape_string($conn, $password);
	//$password = sha1($password);

	// get from db
	$query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Empty data " . mysqli_error($conn);
		exit;
	}
	$row = mysqli_fetch_assoc($result);

	if($email != $row['email'] && $password != $row['password']){
		echo "email or pass is wrong. Check again!";
		$_SESSION['user'] = false;
		exit;
	}

	if(isset($conn)) {mysqli_close($conn);}
	$_SESSION['user'] = true;
	header("Location: userhome.php");
?>