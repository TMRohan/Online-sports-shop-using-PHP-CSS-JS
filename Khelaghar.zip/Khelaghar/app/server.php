<?php
$con=mysqli_connect("localhost","root","","khelaghar") or die('Error');
//$sql="SELECT area FROM dhaka";
$sql="SELECT area FROM sportswear WHERE jersey  LIKE '".$_GET['str']."%'";
$result=mysqli_query($con,$sql);
$arr=array();
$i=0;
while($row=mysqli_fetch_array($result)){
    $arr[$i]=$row['jersey'];
    $i++;
}

echo json_encode($arr);