<?php
	session_start();
	if(!isset($_SESSION['email'])){
		//header("Location:admin_home.php");
	}
	
	$con=mysqli_connect("localhost","root","","khelaghar");
	if (!$con){
		die("Database not connected".mysqli_connect_error());
	}
	
	$email=$_SESSION['email'];
	
	$sql="SELECT * FROM users WHERE email='$email'";
	$result=mysqli_query($con,$sql);
	
	if(mysqli_num_rows($result)>0){
		$row=mysqli_fetch_array($result);
		$fname=$row['fname'];
		$lname=$row['address'];
		$email=$row['email'];
		$phone=$row['phoneno'];
		
	}
	
	if(isset($_POST['update'])){
	
		$name=$_POST['name'];
		$lname=$_POST['address'];
		$phone=$_POST['phoneno'];
		
		
		$sql="UPDATE users SET name='$name', address='$address', phoneno='$phoneno' WHERE email='$email'";
		if(mysqli_query($con,$sql)){
			header("Location:admin_home.php");
		}
		else{
			echo "Error in updating: ".mysqli_error($con);
		}
	}
?>

<html>
	<head>
		<title> Edit Profile</title>
	</head>

	<body bgcolor="black" height="768" width="1366">
		<font face="arial">
			<?php
				//include_once "./template/header.php";
                 include_once "./functions/database_functions.php";
			?>
			</br>
			<table align="center">
			<br/>
				<tr>
					<td width="250" align="center">
						<fieldset>
							<legend></legend>
							
							<p align="center"><b><font color="white" size="4">User<font></b></p>
							<hr>
							
							
							
	
					<hr>
					<p>&nbsp <a href="admin_signout.php"><b><font color="white" size="4">Logout</font></b></a></p>
						</fieldset>
					</td>
					
			
				<td width="800" align="center">
					<fieldset>
						<legend></legend>
						<p><font color="FF7D00" size="6"><b>Edit Profile</b></font></p>
						<br/><br/>
						<form action="admin_profile.php" method="POST">
							<table align="center" height="420" width="550">
								<tr>
									<td align="left"colspan="4">
										<p><font color="white" size="3">Choose an image:</font></p>
										<img src="bootstrap/img/images.png" alt="upload image" height="70"><br/><br/>
										<font color="white" size="3"><input type="file" name="file"/></font>
									</td>
								</tr>
								
								<tr valign="top" height="40">
									<td><b><font color="white" size="3">Name</font></b></td>
									<td colspan="3"><input type="text" name="name"value="<?php echo "$name";?>" size="60"/></td>
								</tr>

								<tr valign="top" height="40">
									<td><b><font color="white" size="3">Address</font></b></td>
									<td colspan="3"><input type="text" name="address"value="<?php echo "$address";?>" size="60"/></td>
								</tr>
								
								<tr valign="top" height="40">
									<td><b><font color="white" size="3">Email</font></b></td>
									<td colspan="3"><input type="text" name="email"value="<?php echo "$email";?>" size="60"/></td>
								</tr>
						
								<tr valign="top" height="40">
									<td><b><font color="white" size="3">Phone Number</font></b></td>
									<td colspan="3"><input type="text" name="phoneno" value="<?php echo "$phoneno";?>"size="60"/></td>
								</tr>
								
								
								
								<tr>
									<td align="center" colspan="4"><button type="submit" name="submit"><b><font color="black" size="4">Submit</font></b></button></td>
								</tr>
							</table>
						</form>
						<br/><br/>
					</fieldset>
				</td>	
			</tr>
		</table>
		<br/>
		<?php 
			include 'footer.php';
		?>
 
    </font>
	</body>
</html>