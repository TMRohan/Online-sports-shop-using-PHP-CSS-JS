<?php
  session_start();
  $count = 0;
  // connect database
  
  $title = "Index";
  include_once "./functions/user_home.php";
  include_once "./template/cusheader.php";
  include_once "./functions/database_functions.php";
  include_once "./functions/app/server.php";
  include_once "./functions/app/shoes.json";
  include_once "./functions/app/jersey.json";
  $conn = db_connect();
  $row = select4Latestproduct($conn);
?><br/>
<br/>
<html>
    <head>
        <title></title>
    </head>
    <body>
        <select id="sportswear" onchange="loadArea()">
            <option>--Please select Category--</option>
            <option>Jersey</option>
            <option>Shoes</option>
        </select>

        <select id="jersey">
            <option>--Please select Product Type--</option>
            
        </select>
        <p></p>
        <hr>
        <input type="text" onkeyup="searchArea(this.value)">
        <br/>
        <p id="par"></p>
        <script>
            function searchArea(str){
                let para=document.getElementById('par');
                para.innerHTML="";
                let ajax=new XMLHttpRequest();
                ajax.onreadystatechange=function(){
                    if(this.readyState==4 && this.status==200)
                    {
                       
                        let areaData=JSON.parse(ajax.responseText); 
                        for (let index = 0; index < areaData.length; index++) {
                            para.innerHTML+=areaData[index]+",";
                        }
                        
                    }
                }
                
                    ajax.open("GET","./app/server.php?str="+str,true);
                    ajax.send();
                
            }
            function clearCombo(){
                
                let len=jersey.length;
                for (let index = 0; index <len ; index++) {
                    area.remove(area[index]);

                }
                //area.length=0;
            }
            function loadArea(){
                let sportswear=document.getElementById('sportswaer');
                let jersey=document.getElementById('jersey');
                clearCombo();
                let ajax=new XMLHttpRequest();
                ajax.onreadystatechange=function(){
                    if(this.readyState==4 && this.status==200)
                    {
                        let areaData=JSON.parse(ajax.responseText);
                        for (let index = 0; index < areaData.length; index++) {
                            let option=document.createElement("option");
                            if(sportswear.value=="jersey"){
                                option.text=areaData[index];
                                
                            }
                            else if(sportswear.value=="shoes"){
                                option.text=areaData[index].area;
                            }
                            area.add(option);
                            
                            
                            
                        }
                        
                    }
                }
                if(sportswear.value=="jersey"){
                    ajax.open("GET","./app/server.php",true);
                    ajax.send();
                }
                else if(sportswear.value=="shoes"){
                    ajax.open("GET","./app/shoes.json",true);
                    ajax.send();
                }
                else{}
               
            }
        </script>
    </body>
</html>

      <!-- Example row of columns -->
      <p class="lead text-center text-muted">Latest products</p>
      <div class="row">
        <?php foreach($row as $product) { ?>
      	<div class="col-md-3">
      		<a href="product.php?productId=<?php echo $product['productId']; ?>">
           <img class="img-responsive img-thumbnail" src="./bootstrap/img/<?php echo $product['image']; ?>">
          </a>
      	</div>
        <?php } ?>
      </div>
<?php
  if(isset($conn)) {mysqli_close($conn);}
  include_once "./template/footer.php";
?>