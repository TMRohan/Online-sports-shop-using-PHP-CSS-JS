<html>
    <head>
        <title>Change Password</title>
    </head>
    <body >
        
        <form bgcolor="#3498DB" action="changepasswordvalidation.php" method="post">
		   <table bgcolor="#3498DB" width="500" border="1">
		   
            <fieldset>
                <legend> Change Password : </legend>
                    Current Password&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <input type="password" name="password"/><br/><br/>
                    <font color="#43734A">New Password<font/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <input type="password" name="newPassword"/><br/><br/>
                    <font color="red">Retype New Password<font/> : <input type="password" name="retypePassword"/><br/><br/>
                    <hr color="black">

                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="submit"/>
            </fieldset>
			</table>
        </form>
    </body>
</html>