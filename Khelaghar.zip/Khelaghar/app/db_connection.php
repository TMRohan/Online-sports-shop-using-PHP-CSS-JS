<?php


    function connection()
    {
       $con=mysqli_connect("localhost","root","","khelaghar");
	   return $con; 
    }

?>