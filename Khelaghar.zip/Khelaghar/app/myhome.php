<?php
	session_start();
	include_once "./functions/user_home.php";

//if(!isset($_SESSION['email']))
{
	//header("Location:Login.php");
}
	$con=mysqli_connect("localhost","root","","khelaghar");//database connection
	if (!$con)
	{
		die("Database not connected".mysqli_connect_error());
	}
	$email=$_SESSION['email'];
	
	$sql="SELECT * FROM users WHERE email='$email'";
	$result=mysqli_query($con,$sql);	
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$name=$row['name'];
		$address=$row['address'];
		$email=$row['email'];                       //fetch data
		$phoneno=$row['phoneno'];
		

		//echo "$fname $lname";
	}

?>

<html>
	<head>
		<title>My Profile</title>
	</head>

	<body bgcolor="black" height="768" width="1366">
		<font face="arial">
			<?php
				//include_once "./template/header.php";
                 include_once "./functions/database_functions.php";
			?>
			</br>
			<table align="center">
			<br/>
				<tr>
					<td width="250" align="center">
						<fieldset>
							<legend></legend>
							
							<p align="center"><b><font color="white" size="4">User<font></b></p>
							<hr>
							
							
	
					
					<p>&nbsp <a href="admin_signout.php"><b><font color="white" size="4">Logout</font></b></a></p>
						</fieldset>
					</td>
					
					<td width="800" align="center">
						<fieldset>
							<legend></legend>
							<p><font color="red" size="6"><b>My Profile</b></font></p>
							<table>
								<tr>
									<td width="800" align="center">
										<br/><br/><br/>
										<p align="left">&nbsp &nbsp<p>
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Name:<?php echo "$name";?></font></b></p>
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Address:<?php echo "$address";?></font></b></p>
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Email:<?php echo "$email";?></font></b></p>
										
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Mobile No:<?php echo "$phoneno";?></font></b></p>
										<br/><br/>
										<p><a href="useredit.php"><button><b><font color="black" size="5">Edit Profile</font></b></button></a></p>
									</td>
								</tr>
							</table>
							<br/><br/>
						</fieldset>
					</td>
				</tr>
			</table>
			<br/>
			<?php 
				include 'footer.php';
			?>
		</font>
	</body>
</html>