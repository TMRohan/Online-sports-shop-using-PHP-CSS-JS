<html>
     <head>
	      <title>SportsWear</title>
	</head>
		<body bgcolor="#000000">	
			<table bgcolor="#000000">
			   <tr>
		          <th height="30"width="800"align="left"><a href="index.php"><font COLOR="white" size="7">KhelaGhor</font></a></th>
		          
			   </tr>
			</table>
			<table border="1">
			<tr bgcolor="#1C2833">	
			  <th align="center"colspan="3"><font size="6"color="WHITE">SportsWear</th>
			</tr>
               <tr>	
				 <td width="455"height="400"><img src="bootstrap/img/jersey.jpg"width="455"height="400">
				 <td width="455"height="400"><img src="bootstrap/img/shoes.jpg"width="455"height="400">
				 <td width="455"height="400"><img src="bootstrap/img/caps.jpg"width="455"height="400">
			   </tr>
			    <tr bgcolor="#1C2833">	
			        <td valign="bottom"align="center" width="455"height="20"><a href="jersey.php"><button><b><font color="blue" size="5">Jersey</font></b></button></a></td>
					<td valign="bottom" align="center" width="455"height="20"><a href="shoes.php"><button><b><font color="blue" size="5">Shoes</font></b></button></a></td>
					<td valign="bottom" align="center" width="455"height="20"><a href="caps.php"><button><b><font color="blue" size="5">Caps</font></b></button></a></td>
			  </tr>
			
			
			
			
			</table>
			<?php
		   include 'footer.php';
	    ?>
		
			
			
			
			
			
			
			
			
			
			
			
		</body>
</html>		