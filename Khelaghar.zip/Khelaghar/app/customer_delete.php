<?php
	$customerId = $_GET['customerId'];

	require_once "./functions/database_functions.php";
	$conn = db_connect();

	$query = "DELETE FROM customer WHERE customerId = '$customerId'";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "delete data unsuccessfully " . mysqli_error($conn);
		exit;
	}
	header("Location: admin_user.php");
?>