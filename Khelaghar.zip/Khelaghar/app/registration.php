<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $title; ?></title>

    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
   
  </head>
  <?php
	$title ="";
	include_once "./template/header.php";
?>
<?php
    function checkName($s) 
	{
		 $len=strlen($s);
		 $ok=0;
		 if($len<2){
			 echo "Name must contains at least two words";
			 exit();
		 }
		 for($i=0;$i<$len;$i++){
		 if(($s[$i]>='a' && $s[$i]<='z')||($s[$i]>='A' && $s[$i]<='Z')||$s[$i]=='-'||$s[$i]==' ')
			{
				$ok=1;
			}
			else{
				echo "Name can contain a-z, A-Z, period, dash only";
				exit();
			}
		 }
		 if(!$ok){
			 echo "Invalid name";
			 exit();
		 }
	}
    
    
    function checkPassword($s,$p) 
	{
		$len=strlen($s);
		
        if($len<6){
			echo "Password should be at least 6 character!";
			
		}
		
		else if($s!=$p){echo "Password must match with the Retyped Password";exit();}
    }
    
    function checkMail() { 
		if(empty($_POST['email'])){
			echo "Email required";
			exit();
		}
		else{
			$email =$_POST["email"];
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				echo "Invalid email format"; 
				exit();
			}
		}
    }
    
    function checkGender(){  
        if(empty($_POST['gender'])){
			echo "Gender is not selected!";
			exit();
		}
		
     }
	  function checkaddress(){  
        if(empty($_POST['address'])){
			echo "address is not selected!";
			exit();
		}
		
     }

     if(isset($_POST['submit'])){
         checkName($_POST['name']);
		 checkMail();
		 checkPassword($_POST['pw'],$_POST['repw']);
		 checkaddress();
		 checkGender();
		 
		 echo "<h2> Reginstration done! </h2>";
		 				 include 'login.php';

     }
?>
<html>
	<head> <title>Login page</title> </head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
     <style>
     body {
   margin-right:30px;
   background-color: white;
     }

   </style>
	
				<body>
					<form action="" method="post">
						<table align="center" border="1">
		                 <tr>
			             <td>
					<fieldset >
						<legend><font size="4">Registration</font></legend>
                        
							 	<lable> Name :</lable> 
                                 <input type="text" name="name"/><br/><br/>
							
							
							 	<lable>Email :</lable>
                                 <input type="email" name="email"/><br/><br/>
							
							
							 	<lable>Password :</lable> 
                                 <input type="password" name="pw"/><br/><br/>
							
							
							 	<lable>Cofirm Password :</lable> 
                                <input type="password" name="repw"/><br/><br/>
								
								<lable> Address :</lable> 
								
                                 <input type="text" name="address"/><br/><br/>
							
							
								
							  		<fieldset>
									<legend>Gender</legend>
									<input type="radio" name="gender" value="Male"/>Male
									<input type="radio" name="gender" value="Female"/>Female
									<input type="radio" name="gender" value="Other"/>Other
							  		</fieldset>
							 
								
							  		<fieldset>
									<legend>Date Of Birth</legend>
									<input type="number" name="day" min="1" max="31"/>/
									<input type="number" name="month" min="1" max="12"/>/
									<input type="number" name="year" min="1953" max="2018"/>/
									<label><font size="2">(mm/dd/yyyy)</font></label>
							  		</fieldset>
							 	<hr>
								<input type="submit" name="submit" value="Submit"/>
								<input type="reset" name="reset" value="Reset"/>
									
                   </fieldset>
			</td>
		</tr>
	</table> 
   </form>
  </body>
</html>