<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $title; ?></title>

    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
   
  </head>
<?php
  session_start();
  $productId = $_GET['productId'];
  // connecto database
  require_once "./functions/database_functions.php";
  $conn = db_connect();

  $query = "SELECT * FROM product WHERE productId = '$productId'";
  $result = mysqli_query($conn, $query);
  if(!$result){
    echo "Can't retrieve data " . mysqli_error($conn);
    exit;
  }

  $row = mysqli_fetch_assoc($result);
  if(!$row){
    echo "Empty book";
    exit;
  }

  $Name = $row['Name'];
  require "./template/header.php";
?>
      <!-- Example row of columns -->
      <p class="lead" style="margin: 25px 0"><a href="books.php">Products</a> > <?php echo $row['Name']; ?></p>
      <div class="row">
        <div class="col-md-3 text-center">
          <img class="img-responsive img-thumbnail" src="./bootstrap/img/<?php echo $row['image']; ?>">
        </div>
        <div class="col-md-6">
          <h4>Product Description</h4>
          <p><?php echo $row['description']; ?></p>
          <h4>Product Details</h4>
          <table class="table">
          	<?php foreach($row as $key => $value){
              if($key == "description" || $key == "image" ||$key == "Name"){
                continue;
              }
              switch($key){
                case "productId":
                  $key = "productId";
                  break;
                case "Name":
                  $key = "Name";
                  break;
                case "book_author":
                  $key = "Author";
                  break;
                case "price":
                  $key = "price";
                  break;
              }
            ?>
            <tr>
              <td><?php echo $key; ?></td>
              <td><?php echo $value; ?></td>
            </tr>
            <?php 
              } 
              if(isset($conn)) {mysqli_close($conn); }
            ?>
          </table>
          <form method="post" action="cart.php">
            <input type="hidden" name="productId" value="<?php echo $productId;?>">
            <input type="submit" value="Purchase / Add to cart" name="cart" class="btn btn-primary">
          </form>
       	</div>
      </div>
<?php
  require "./template/footer.php";
?>