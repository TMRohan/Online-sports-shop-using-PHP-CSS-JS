<?php
session_start();
	require_once "./functions/admin_home.php";
?>
<html>
	<head>
		<title>Admin Profile</title>
	</head>

	<body bgcolor="black" height="768" width="1366">
		<font face="arial">
			<?php
				//include_once "./template/header.php";
                 include_once "./functions/database_functions.php";
			?>
			</br>
			<table align="center">
			<br/>
				<tr>
					<td width="250" align="center">
						<fieldset>
							<legend></legend>
							
							<p align="center"><b><font color="white" size="4">Admin<font></b></p>
							<hr>
							
							<hr>
							<p>&nbsp <a href="admin_book.php"><b><font color="white" size="4">All products</font></b><br/></button></b></a></p>
							<hr>
							&nbsp <a href="admin_order.php"><b><font color="white" size="">Orderd products</font></b></a></p>
							<hr>
							<p>&nbsp <a href="admin_user.php"><b><font color="white" size="4">All User</font></b></a></p>
							
	
					<hr>
					<p>&nbsp <a href="admin_signout.php"><b><font color="white" size="4">Logout</font></b></a></p>
						</fieldset>
					</td>
					
					<td width="800" align="center">
						<fieldset>
							<legend></legend>
							<p><font color="red" size="6"><b>Admin Profile</b></font></p>
							<table>
								<tr>
									<td width="800" align="center">
										<br/><br/><br/>
										<p align="left">&nbsp &nbsp<p>
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Name: Admin</font></b></p>
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Username: admin</font></b></p>
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Email: admin@gmail.com</font></b></p>
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Gender: Male</font></b></p>
										<p align="left">&nbsp &nbsp<b><font color="white" size="4">Mobile No: 01811223344</font></b></p>
										<br/><br/>
										<p><a href="admin_edit_profile.php"><button><b><font color="black" size="5">Edit Profile</font></b></button></a></p>
									</td>
								</tr>
							</table>
							<br/><br/>
						</fieldset>
					</td>
				</tr>
			</table>
			<br/>
			<?php 
				include 'footer.php';
			?>
		</font>
	</body>
</html>